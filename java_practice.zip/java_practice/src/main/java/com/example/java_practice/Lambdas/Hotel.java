package com.example.java_practice.Lambdas;

public class Hotel {
    public int price;
    public int rating;
    public HotelType hotelType;

    public Hotel(int price, int rating, HotelType hotelType) {
        this.price = price;
        this.rating = rating;
        this.hotelType = hotelType;
    }

    public int getPrice() {
        return price;
    }

    public int getRating() {
        return rating;
    }

    public HotelType getHotelType() {
        return hotelType;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public void setHotelType(HotelType hotelType) {
        this.hotelType = hotelType;
    }
}
