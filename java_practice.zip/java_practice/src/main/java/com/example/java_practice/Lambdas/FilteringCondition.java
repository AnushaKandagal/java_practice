package com.example.java_practice.Lambdas;

// Note: Lambdas require using interfaces with only 1 abstract method, such interfaces are called as functional interfaces
// Overridden abstract methods from parent class are not counted
// Default methods are also not counted and functional interfaces can have multiple default methods
@FunctionalInterface
public interface FilteringCondition {
    boolean filter(Hotel hotel);
}

// Examples of using functional interfaces
// 1. Using lambdas as comparators.
// Comparator<T> is an example of functional interface which has only 1 abstract method i.e int compare()

/*
 List<Integers> numbers = List.of(1, 2, 3, 4, 5);
 Collections.sort(numbers, (Integer a, Integer b)-> { return a -b});

 OR

 Collections.sort(numbers, ( a, b)-> { return a -b});
 The compiler is intelligent to understand and infer the data type

 */

/// NOTE: Java already has an interface class called as predicate which does exactly same job as above interface.