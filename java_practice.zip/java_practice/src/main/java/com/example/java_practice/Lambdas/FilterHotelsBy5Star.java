package com.example.java_practice.Lambdas;

public class FilterHotelsBy5Star implements FilteringCondition{

    @Override
    public boolean filter(Hotel hotel) {
        return (hotel.hotelType == HotelType.FIVE_STAR);
    }
}
