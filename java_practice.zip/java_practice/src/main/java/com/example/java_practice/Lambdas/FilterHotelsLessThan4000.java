package com.example.java_practice.Lambdas;

public class FilterHotelsLessThan4000 implements FilteringCondition{
    @Override
    public boolean filter(Hotel hotel) {
        return (hotel.getPrice() < 4000);
    }
}
