package com.example.java_practice.Lambdas;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

public class HotelService {
    public List<Hotel> hotelList = new ArrayList<>();

    public HotelService(){
        hotelList.add(new Hotel(1000, 4, HotelType.ONE_STAR));
        hotelList.add(new Hotel(2000, 5, HotelType.TWO_STAR));
        hotelList.add(new Hotel(3000, 6, HotelType.THREE_STAR));
        hotelList.add(new Hotel(4000, 7, HotelType.FOUR_STAR));
        hotelList.add(new Hotel(5000, 9, HotelType.FIVE_STAR));
        hotelList.add(new Hotel(5900, 10, HotelType.FIVE_STAR));
        hotelList.add(new Hotel(4500, 8, HotelType.FOUR_STAR));
    }
    private boolean is5starHotel(Hotel hotel) {
        return (hotel.hotelType == HotelType.FIVE_STAR);
    }

    public List<Hotel> filter5starHotels(){
        List<Hotel> filteredHotels = new ArrayList<>();
        for(Hotel hotel: hotelList){
            if(is5starHotel(hotel))
                filteredHotels.add(hotel);
        }
        return filteredHotels;
    }

    public List<Hotel> filterHotelsByPrice(int price){
        List<Hotel> filteredHotels = new ArrayList<>();
        for(Hotel hotel: hotelList){
            if(isHotelPriceLessThan(price, hotel))
                filteredHotels.add(hotel);
        }
        return filteredHotels;
    }

    private boolean isHotelPriceLessThan(int price, Hotel hotel) {
        return (hotel.getPrice() <= price);
    }

    // Now we can see that in both functions filterHotelsByPrice, filter5starHotels, everything in common
    // except for line 23 and 32 condition/function
    // One way to reduce redundant code is to pass those conditions as a parameter to 1 common function
    // The idea is to pass conditions such as in line 23, 32 as parameters to a generic function.
    // Below is a must implement method that takes an argument of type interface, can be used in 2 ways
    // 1 . lambda expressions
    // 2 . Passing an instance of class that implements the interface

    public List<Hotel> filterHotels(FilteringCondition filteringCondition){
        List<Hotel> filteredHotels = new ArrayList<>();
        for (Hotel hotel: hotelList){
            if(filteringCondition.filter(hotel))
                filteredHotels.add(hotel);
        }
        return filteredHotels;
    }

    /// NOTE: Java already has an interface class called as predicate which does exactly same job as above interface.
    /// This predicate class uses test method instead of filter method.
    public List<Hotel> filterHotels(Predicate<Hotel> filteringCondition){
        List<Hotel> filteredHotels = new ArrayList<>();
        for (Hotel hotel: hotelList){
            if(filteringCondition.test(hotel))
                filteredHotels.add(hotel);
        }
        return filteredHotels;
    }

}
