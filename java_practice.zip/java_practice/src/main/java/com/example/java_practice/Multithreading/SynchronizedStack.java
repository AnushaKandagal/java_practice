package com.example.java_practice.Multithreading;

// try running this code once by removing the synchronization & locks to simulated thread conflicts
public class SynchronizedStack{
    private int[] array;
    private int top;
    Object lock;


    public SynchronizedStack(int capacity){
        this.array = new int[capacity];
        this.top = -1;
        this.lock = new Object();
    }

    public boolean push(int val) throws InterruptedException {
        synchronized (lock) {
            if (top >= array.length - 1) {
                System.out.println(Thread.currentThread().getName() + "stack full");
                return false;
            }
            top++;
            try {Thread.sleep(5000); } catch (InterruptedException e) {};
            array[top] = val;
            System.out.println(Thread.currentThread().getName() + " pushed value: " + val + " top: " + top);
            return true;
        }

    }

    public int pop(){
        synchronized (lock){
            if(top <= -1){
                System.out.println(Thread.currentThread().getName()+ " Stack empty");
                return Integer.MIN_VALUE;
            }
            int val = array[top];
            array[top] = Integer.MIN_VALUE;
            top--;
            System.out.println( Thread.currentThread().getName()+" popped value: "+val + " top: "+ top);
            return val;
        }
    }

    // Note: lock can be any java object, if we want 2 methods to be thread safe then same object should
    // be passed as a lock object as shown in push and pop methods.
    // If we want the entire method to be synchronized we can simply declare the method as synchronized as shown below.
    public synchronized void pushSync(int val){
        array[top] = val;
        top++;
    }
    // for above method, the compiler will apply a lock of "this" object by default as implemented below
    /*public void pushSync(int val){
        synchronized (this){
            array[top] = val;
            top++;
        }
    }*/

    //In case of synchronized static methods where an instance/this object might not be required,(similar to Singleton)
    // The compiler by default sends .class object as the lock as shown below
    public synchronized static void staticMethod(){
        System.out.println("static method called by: "+Thread.currentThread().getName());
    }
    // Below is the compiler interpretation of this method
   /* public static void staticMethod(){
        synchronized (SynchronizedStack.class){
            System.out.println("static method called by: "+Thread.currentThread().getName());
        }
    }*/
}
