package com.example.java_practice;

import com.example.java_practice.DataStructures.HashSetPractice;
import com.example.java_practice.Deadlock.Deadlock;
import com.example.java_practice.Lambdas.*;
import com.example.java_practice.Multithreading.MulithreadClass;
import com.example.java_practice.Multithreading.MultithreadClass2;
import com.example.java_practice.Multithreading.SynchronizedStack;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import com.example.java_practice.DataStructures.ArrayListPractice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.function.*;

@SpringBootApplication
public class JavaPracticeApplication {

    public static void main(String[] args) {
        /*SpringApplication.run(JavaPracticeApplication.class, args);

        System.out.println("Performing arrayList operations");
        ArrayList<Integer> list = new ArrayList<>(Arrays.asList(2,3,4));
        ArrayListPractice arrayListPractice = new ArrayListPractice(list);
        arrayListPractice.performArrayListOperations();

        System.out.println("Performing HashSetOperations operations");
        HashSetPractice hashSetPractice = new HashSetPractice();
        hashSetPractice.performHashSet();*/


        /*for(int i = 0 ; i < 2; i++){
            MulithreadClass mc1 = new MulithreadClass();
            System.out.println("calling run(): ");
            mc1.run();
        }

        for(int i = 0 ; i < 5; i++){
            MulithreadClass mc2 = new MulithreadClass();
            System.out.println("calling start(): ");
            mc2.start();
            //mc2.start(); // causes IllegalStateException
        }*/

        // .join method defeats the purpose of multithreading,
        // it waits for the completing of the current thread before executing a new thread.

        /*for(int i = 0 ; i < 2; i++){
            MultithreadClass2 mc3 = new MultithreadClass2();
            //mc3.start(); cannot directly invoke start() as it doesnt extend thread class directly.
            // needs an overhead of creating a Thread instance
            Thread myThread = new Thread(mc3);
            myThread.start();
            try {
                myThread.join();
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }*/

        /*//Daemon threads, main thread (program) migth finish or might not finish befire deamon thread.
        // Process can terminate once all user threads are finished, regardless of the state of deomon threads.
        System.out.println("main thread starting....");
        MulithreadClass deamonThread = new MulithreadClass();
        deamonThread.setDaemon(true);
        deamonThread.start();
        System.out.println("main thread ended.....");
*/

        /*//Using lamba function, we dont need to create a class that extends Thread/Runnable
        // But arrow function will execute when start method is called.
        String abc = "abc";
        for(int i = 0; i < 3; i++) {
            Thread lambaThread = new Thread(() -> {
                for (char a: abc.toCharArray() )
                    System.out.println(Thread.currentThread().getName() + " thread running " + a);
            });
            lambaThread.start();
        }*/

        /*//Synchronization using locks
        SynchronizedStack stack = new SynchronizedStack(5);
         new Thread(()->{
            for(int i = 0 ; i < 10; i++) {
                try {
                    stack.push(i+5);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        }, "Thread1").start();

         new Thread(()->{
            for (int i = 0; i < 10; i++)
                stack.pop();
            stack.staticMethod();
        }, "Thread2").start();
    }*/

       /* System.out.println("Main executing deadlock");
        Deadlock deadlock = new Deadlock();
        Thread deadlockThread1 = new Thread(() -> {
            try {
                deadlock.method1();
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }, "deadlockThread1");
        Thread deadlockThread2 = new Thread(()->{
            try {
                deadlock.method2();
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        },"deadlockThread2");
        deadlockThread1.start();
        deadlockThread2.start();

        try {
            deadlockThread1.join();
            deadlockThread2.join();
            // such that main waits for the 2 threads to finish
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        System.out.println("ending deadlock");*/

        // LAMBDA FUNCTIONS
        /*
            1. Using functions as parameters without using lamdas as paramters but
                by wrapping functions un interfaces.
            2. Lambdas use this implementations behind the scenes.
            3. Using anonymous inner class, by this way we can pass an instance of an
            anonymous class that implements the interface within a class. refer below example of hotelsWithRatings8Plus
         */
        /*HotelService hotelService = new HotelService();
        List<Hotel> hotels5Star = hotelService.filterHotels(new FilterHotelsBy5Star());
        for (Hotel hotel: hotels5Star){
            System.out.println(hotel.getHotelType().toString() +":"+ hotel.getRating());
        }
        List<Hotel> hotelsLessThan4000 = hotelService.filterHotels(new FilterHotelsLessThan4000());
        for (Hotel hotel: hotelsLessThan4000){
            System.out.println(hotel.getHotelType().toString() +":"+ hotel.getPrice());
        }*/

        /*
        List<Hotel> hotelsWithRatings8Plus = hotelService.filterHotels(new FilteringCondition() {
            @Override
            public boolean filter(Hotel hotel) {
                return (hotel.getRating() >= 8);
            }
        });
        for (Hotel hotel: hotelsWithRatings8Plus){
            System.out.println(hotel.getRating() +":"+ hotel.getPrice());
        }

        // Below is the lambda implementation of the same, this way we can avoid creating a separate class that
        // implements the interface. Note since we do not specify that the method implemented by the lambda expression
        // should be filter method , hence it is required to have only 1 abstract method in the interfaces.
        // so for lambdas it is mandatory to use functional Interfaces.
        List<Hotel> hotelsWithGoodRatings = hotelService.filterHotels((Hotel hotel)->{
            return (hotel.getRating() >= 8);
        });
        for (Hotel hotel: hotelsWithRatings8Plus){
            System.out.println(hotel.getRating() +":"+ hotel.getPrice());
        }*/

        // What if we have a interface with more than 1 methods? Then above 2 syntaxs won't work.
        // solution for such cases: Lamdas can be used only with interfaces with only 1 method (functional interfaces)


        /*// GOOD example of lambdas is comparator function, Comparator and Runnable
        List<Integer> numbers = List.of(1, 2, 3, 4, 5);
        Comparable<>;
        Collections.sort(numbers, (Integer a, Integer b)-> { return a -b;});
        // The compiler is intelligent to understand and infer the data type as shown below
        Collections.sort(numbers, (a,b) -> a -b);
        // same as
        Collections.sort(numbers, (Integer a, Integer b) -> {
            return a -b;
        });*/

/*
        // Lambda expression type checking ( passing lambda expression as parameter )
        FilteringCondition lambda = (Hotel hotel) -> { return (hotel.getRating() >= 8);};
        // or
        FilteringCondition lambda1 = hotel -> hotel.getRating() >= 8;
        hotelService.filterHotels(lambda);
        hotelService.filterHotels(lambda1);*/


        testConsumerSupplierInterface();
        testFunctionInterface();



    }

    // LAMBDAS THIS CONTEXT AND USING LOCAL VARIABLES, capturing local variable value ( final)
    private int someField;

    public List<Hotel> testLambdas(List<Hotel> hotels){

        HotelService hotelService = new HotelService();
        int price = 100;
        List<Integer> ar = new ArrayList<>();
        FilteringCondition lambdaExp = hotel -> {
            // "this" refers to the inclosing class where the lambdas exp is created and not the
            // anonymous class ( which implements FilteringCondition interface) that is created implicitly by lambda.
            System.out.println(this.someField);
            System.out.println(price);
            //price++;
            // ERROR , any local variable like price used within lambda expression will be final/effectively final
            System.out.println(ar.size());
            return hotel.getRating() >= 5;
        };
        //price++; causes error inside lamdas , as it is treated as final and cannot be changed
        ar.add(1); // NOTE: like price , this doesnt cause any error, since ar still points to same object in heap memory
        //ar = new ArrayList<>(); ERROR: now ar doesnt point to same object, hence it is considered as changed,
        // but it cannot be changed as ar is effective final
        return  hotelService.filterHotels(lambdaExp);
    }

    public void testPrdicateInterface(){
        Predicate<Integer> divisibleBy2 = i -> i % 2 == 0;
        Predicate<Integer> divisibleBy3 = i -> i % 3 == 0;
        Predicate<Integer> divisibleBy6 = divisibleBy2.and(divisibleBy3);
        Predicate<Integer> divisibleBy2Or3 = divisibleBy2.or(divisibleBy3);

        System.out.println(divisibleBy2.test(2));
        System.out.println(divisibleBy3.test(9));
        System.out.println(divisibleBy2Or3.test(12));

        // For predicate interface there are custom-made predicate classes
        // for primitive data types to address performance issues caused by type casting.
        // ForEx IntPrdicate, DoublePredicate
        IntPredicate isEven = i -> i%2 == 0 ;

    }

    public static void testConsumerSupplierInterface(){
        List<Integer> list = new ArrayList<>();
        list.add(1);
        list.add(2);
        list.add(3);
        Consumer<Integer> consumer = i -> System.out.println("i value: "+i);
        consumer.accept(0);
        list.forEach(consumer);

        Supplier<Double> supplier = () -> Math.random();
        System.out.println(supplier.get());
        // For SUPPLIER interface there are custom-made predicate classes
        // for primitive data types to address performance issues caused by type casting.
        // ForEx DoubleSupplier
        DoubleSupplier doubleSupplier = () -> Math.random();
        System.out.println(doubleSupplier.getAsDouble());
    }

    public static void testFunctionInterface(){
        // An interface with function takes input of paramter of 1st data type
        // and returns a value with 2nd data type
        Function<String, Integer> function = string -> Integer.parseInt(string) ;
        System.out.println(function.apply("123"));

        Function<Integer, Integer> sqaures = i -> i * i;
        Function<Integer, Integer> doubles = i -> i * 2;

        Integer result = sqaures.andThen(doubles).apply(5);
        System.out.println(result);
    }


}
