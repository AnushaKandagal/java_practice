package com.example.java_practice.Lambdas;

public enum HotelType {
    ONE_STAR, TWO_STAR, THREE_STAR, FOUR_STAR, FIVE_STAR;
}
