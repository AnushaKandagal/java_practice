package com.example.java_practice.Multithreading;

public class MulithreadClass extends Thread{

    private String threadId;
    @Override
    public void run(){
        this.threadId = Thread.currentThread().getName();

        for(int i = 0 ; i < 3; i++){
            System.out.println(i + " excecuted by thread:" + threadId);
        }

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}
