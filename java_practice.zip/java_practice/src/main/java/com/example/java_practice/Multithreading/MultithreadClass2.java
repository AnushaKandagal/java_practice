package com.example.java_practice.Multithreading;

public class MultithreadClass2 implements Runnable{
    private String threadName;
    @Override
    public void run(){
        this.threadName = Thread.currentThread().getName();
        for(int i = 0 ; i < 3; i++){
            System.out.println(i+"from thread: "+ threadName);
        }
    }
}
