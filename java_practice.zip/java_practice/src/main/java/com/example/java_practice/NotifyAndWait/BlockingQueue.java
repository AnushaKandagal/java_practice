package com.example.java_practice.NotifyAndWait;

import java.util.*;

public class BlockingQueue {
    private Queue<Integer> q;
    private int cap;

    public BlockingQueue(int cap) {
        this.q = new LinkedList<Integer>();
        this.cap = cap;
    }

    // during wait state the thread releases the LOCK and allows the other thread outside the sync code to enter
    public boolean add(int item){
        synchronized (q){
            // important to use WHILE instead of if , since more than 1 thread could be in wait state for an item to be removed
            // once an item is removed and the capacity is not full, all the waiting threads will be notified to be executed at once
            // hence the capacity could be max again
            // but sleep() state will not release the lock.
            while(q.size()== cap){
                try {
                    // waits for some other thread to perform remove and notify this thread.
                    // we can also pass some time inside wait method
                    q.wait();
                    // after notified, it will execute once it acquires the lock.
                    // NOTE: until the lock is still not acquired, the thread continues to be on blocked state.
                } catch (InterruptedException e) {
                    // the thread will throw this exception once it finishes its waiting time , if it was interrupted by some other thread during its wait.
                    throw new RuntimeException(e);
                }
            }
            q.add(item);
            q.notifyAll();
            // this method is by-default methods of all java object class
            // this method is to notify all the thread that are in q.wait() sate to be awakened to continue execution.
            return true;
        }
    }

    public int remove(int item){
        synchronized (q){
            if (q.isEmpty()){
                try {
                    // waits for some thread to add items and notify this thread.
                    q.wait();
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
            int element = q.poll();
            q.notifyAll(); // notified other thread that are in q.wait state to be awakened.
            return element;
        }
    }
}
