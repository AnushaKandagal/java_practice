package com.example.java_practice.Deadlock;

public class Deadlock {
    String lock1 = "lock1";
    String lock2 = "lock2";

    public void method1() throws InterruptedException {
        synchronized (lock1){
            System.out.println(Thread.currentThread().getName()+ "acquired lock1");
            Thread.sleep(5000);
            synchronized (lock2){
                System.out.println("lock2 acquired by:"+ Thread.currentThread().getName());
            }
        }
    }

    public void method2() throws InterruptedException {
        synchronized (lock2){
            System.out.println(Thread.currentThread().getName()+ "acquired lock2");
            synchronized (lock1){
            System.out.println("lock1 acquired by:"+ Thread.currentThread().getName());
            }
        }
    }
}
